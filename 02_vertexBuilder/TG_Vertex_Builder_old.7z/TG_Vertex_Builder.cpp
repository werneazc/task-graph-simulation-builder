//! \file TG_Vertex_Builder.h
//! \brief Vertex builder helper functions

#include "TG_Vertex_Builder.h"
#include <string>
#include <exception>
#include <fstream>
#include <iomanip>

const std::map<cv_tools::TG_VertexType, std::string > vc_utils::VertexSimulationTypes = {
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::BinOpMulVertex, "MulVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::BinOpDivVertex, "DivVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::BinOpRemVertex, "ModVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::BinOpAddVertex, "AddVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::BinOpSubVertex, "SubVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::BinOpShlVertex, "LShiftVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::BinOpShrVertex, "RShiftVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::BinOpLTVertex, "LowerVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::BinOpGTVertex, "GreaterVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::BinOpLEVertex, "LEqualVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::BinOpGEVertex, "GEqualVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::BinOpEQVertex, "EqualVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::BinOpNEVertex, "NotEqualVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::BinOpAndVertex, "BitAndVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::BinOpXorVertex, "BitXorVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::BinOpOrVertex, "BitOrVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::BinOpLAndVertex, "LogicAndVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::BinOpLOrVertex, "LogicOrVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::UnaryOpPostIncVertex, "PostIncVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::UnaryOpPostDecVertex, "PostDecVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::UnaryOpPreIncVertex, "PreIncVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::UnaryOpPreDecVertex, "PreDecVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::UnaryOpNotVertex, "BitNotVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::UnaryOpLNotVertex, "NotVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::ConditionalOpVertex, "TernaryVertex"),
    std::pair<cv_tools::TG_VertexType, std::string>(cv_tools::TG_VertexType::CastVertex, "CastVertex")
};


void vc_utils::findAndEraseUndefined( cv_tools::TaskGraph& _graph )
{
    auto ver = boost::vertices( _graph );

    for ( auto it = ver.first; it != ver.second; ++it )
        {
            auto node = _graph[ *it ];

            if ( ( node.type == cv_tools::TG_VertexType::VarVertex ) &&
                 ( node.outputDataType == "undefined" ) )
                {
                    if ( ( boost::in_degree( *it, _graph ) == 0 ) &&
                         ( boost::out_degree( *it, _graph ) == 0 ) )
                        {
                            boost::remove_vertex( *it, _graph );

#ifdef _DEBUG
                            std::cout << "undefined vertex deleted" << std::endl;
#endif // _DEBUG

                            return;
                        }
                    else
                        throw std::invalid_argument(
                            "Only graphs with initialized variables could be handled." );
                }
            else
                continue;
        }

#ifdef _DEBUG
    std::cout << "undefined vertex not found" << std::endl;
#endif // _DEBUG
}

vc_utils::invariantMap_t vc_utils::getLiterals(const cv_tools::TaskGraph& _graph)
{
    auto ver = boost::vertices(_graph);

    vc_utils::invariantMap_t invariantValues;

    for (auto it = ver.first; it != ver.second; ++it)
    {
        auto currentVertexType = _graph[*it].type;

        if ((currentVertexType == cv_tools::TG_VertexType::IntegerLiteralVertex) ||
            (currentVertexType == cv_tools::TG_VertexType::FloatingLiteralVertex))
        {
            try
            {
                auto stringVal = _graph[*it].description;
                auto vertexId = _graph[*it].vertexID;

                auto len = stringVal.find(" ") + 1;
                
                stringVal.erase(stringVal.begin(), stringVal.begin()  + len);

            	double key = std::stod(stringVal);

               invariantValues[key].push_back(vertexId);

            }
            catch (std::invalid_argument e)
            {
                std::cerr << "error: " << e.what() << std::endl;
                std::cerr << "Only integer and floating literals are valid invariant types" << std::endl;
                std::terminate();
            }
            catch (std::out_of_range e)
            {
                std::cerr << "error: " << e.what() << std::endl;
                std::terminate();
            }
        }
        else
            continue;

    }

    return invariantValues;
}

vc_utils::inputVarList_t vc_utils::getInputVars(const cv_tools::TaskGraph& _graph)
{
    auto ver = boost::vertices(_graph);

    vc_utils::inputVarList_t inputValues;

    for (auto it = ver.first; it != ver.second; ++it)
    {
        if (_graph[*it].type == cv_tools::TG_VertexType::VarInputVertex)
        {
            auto key = _graph[*it].outputDataType;

            inputValues[key].push_back(_graph[*it].vertexID);
        }
        else
            continue;

    }

    return inputValues;
}

vc_utils::outValueMap_t vc_utils::getOutputVars(const cv_tools::TaskGraph& _graph)
{
    vc_utils::outValueMap_t retVal;
    
    auto vecIters = boost::vertices(_graph);

    for (auto vecIt = vecIters.first; vecIt != vecIters.second; ++vecIt)
    {
        if (_graph[*vecIt].type == cv_tools::TG_VertexType::ReturnVertex)
        {
            auto edgeIters = boost::in_edges(*vecIt, _graph);

            for (auto edgeIt = edgeIters.first; edgeIt != edgeIters.second; ++edgeIt)
            {
                auto dataType = _graph[*edgeIt].edgeDataType;
                auto valId = _graph[*edgeIt].parameterPosition;
                auto sourceId = _graph[boost::source(*edgeIt, _graph)].vertexID;
                
                retVal.insert(std::make_pair(sourceId, std::make_pair(dataType, valId)));
            }
            break;
        }
        else
            continue;

    }

    return retVal;
}

vc_utils::vertexClassList_t vc_utils::getVertexClasses(const cv_tools::TaskGraph& _graph)
{
    
    vc_utils::vertexClassList_t retVal;

    auto vecIters = boost::vertices(_graph);

    for (auto vecIt = vecIters.first; vecIt != vecIters.second; ++vecIt)
    {
        auto nodeType = _graph[*vecIt].type;

        if (vc_utils::VertexSimulationTypes.count(nodeType) != 0)
        {
            auto vertexClass = vc_utils::VertexSimulationTypes.at(nodeType) + "< ";

            auto inIters = boost::in_edges(*vecIt, _graph);

            for (auto edgeIt = inIters.first; edgeIt != inIters.second; ++edgeIt)
            {
                if (_graph[*edgeIt].edgeType == "dataflow")
                    vertexClass += _graph[*edgeIt].edgeDataType + ",";
                else
                    continue;
            }

            auto outIters = boost::out_edges(*vecIt, _graph);

            for (auto edgeIt = outIters.first; edgeIt != outIters.second; ++edgeIt)
            {
                if (_graph[*edgeIt].edgeType != "dataflow - condition")
                    vertexClass += _graph[*vecIt].outputDataType + " >";
                else
                    vertexClass.replace(vertexClass.rfind(','), 2, " >");
                    continue;
            }


            auto vertexId = _graph[*vecIt].vertexID;

            retVal[vertexClass].push_back(vertexId);

        }
        else if ( nodeType == cv_tools::TG_VertexType::FunctionCallVertex)
        {
            std::string vertexClass;



        }
        else if (nodeType == cv_tools::TG_VertexType::IfBeginVertex)
        {
            std::cout << "not implemented yet";
        }
        else
        {
#ifdef _DEBUG
            std::cout << "unknown vertex type found" << std::endl;
#endif // _DEBUG
            continue;
        }

    }

    return retVal;

}

void vc_utils::writeMemoryFileBuildInfo(const inputVarList_t& _inputs, const invariantMap_t& _invariants, const outValueMap_t& _outputs)
{
    unsigned int valueId = 0;

    std::ofstream file("memoryDataFile.txt", std::ios_base::out);


    file << "#input value information:\n============================" << std::endl;
    file << "#memory value id" << " | " << "data type" << " | " << "representing vertex ID:" << std::endl;

    for (auto in : _inputs)
    {
        for (auto id : in.second)
        {
            file << valueId++ << " | " << in.first << " | ";
            file << id << std::endl;
        }

    }

    file << "\n#literal value information:\n============================" << std::endl;
    file << "#memory value id" << " | " << "data type" << " | " << "value" << " | "  << "representing vertex ID:" << std::endl;

    for (auto inv : _invariants)
    {
        for (auto id : inv.second)
        {
            file << valueId++ << " | " << "double" << " | " << inv.first << " | ";
            file << id << std::endl;
        }

    }


    file << "\n#result value information:\n============================" << std::endl;
    file << "#memory observer id" << " | " << "data type" << " | " << "predecessor vertex ID:" << " | " << "value id" << std::endl;

    unsigned int obsId = 0;

    for (auto out : _outputs)
    {

        file << obsId++ << " | " << out.second.first << " | " << out.first << " | ";
        file << out.second.second << std::endl;

    }


    file.close();

    return;

}

void vc_utils::writeVertexTypeDefinitions(const vertexClassList_t& _vertices)
{
    std::ofstream file("vertexTypeDefinitions.txt", std::ios_base::out);

    file << "#contains a summery of needed vertex types." << std::endl;
    file << "#the number behind the type lists all vertices which are a member of it. \n\n" << std::endl;

    file << "#Task_Base vertex types\n======================" << std::endl;

    for (auto node : _vertices)
    {
        file << node.first << ": ";
        
        bool firstId = true;
        for (auto id : node.second)
        {
            if (firstId)
            {
                file << id;
                firstId = false;
            }
            else
                file << " | " << id;
        }
        file << std::endl;

    }

    file.close();

}

