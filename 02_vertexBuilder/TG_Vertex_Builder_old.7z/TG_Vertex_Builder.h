//! \file TG_Vertex_Builder.h
//! \brief Vertex builder helper functions

#ifndef TG_VERTEX_BUILDER_H_
#define TG_VERTEX_BUILDER_H_

#include <TaskGraphDef.h>
#include <map>
#include <vector>

namespace vc_utils
{
    //! \typedef vertexIdList_t
    //! \brief vertex id list
    typedef std::vector< unsigned int > vertexIdList_t;


    //! \typedef invariantMap_t
    //! \brief the key is a constant numeric value and the vector saves all literal nodes that have
    //! this value
    //! \details
    //! The idea is, that a literal is a constant in memory.
    //! All nodes in the graph that need this value get a connection to the memory to
    //! read that value from there. To save memory it is checked that the value is only saved once.
    //! At the moment there is only on data field for invariant values in the memory representation
    //! so
    //! all numeric invariants are saved as doubles.
    typedef std::map< double, vertexIdList_t > invariantMap_t;

    //! \typedef inputVarList_t
    //! \brief the key is a numeric data type and the vector saves all input nodes that have this
    //! type
    //! \details
    //! The idea is, that a incoming node is a value in memory.
    //! All nodes in the graph that need this value get a connection to the memory to
    //! read that value from there.
    typedef std::map< std::string, vertexIdList_t > inputVarList_t;


    //! \typedef outValueMap_t
    //! \brief key is source vertex id of output value, value is a pair of type and value ID
    //! \details
    //! This data structure should collect the informations to build memory places and connections
    //! for all generated result values.
    typedef std::map< unsigned int, std::pair< std::string, unsigned int > > outValueMap_t;


    typedef std::map<std::string, vertexIdList_t> vertexClassList_t;

    extern const std::map<cv_tools::TG_VertexType, std::string > VertexSimulationTypes;


    /************************************************************************/
    // findAndEraseUndefined
    //!
    //! \brief find and erase useless undefined vertex
    //!
    //! \details
    //! This vertex is needed to parse valid c-files using uninitialized variables.
    //! In simulator this vertex is forbidden and erased from vertex list.
    //!
    //! \param [in,out] _graph reference to task graph representation
    /************************************************************************/
    void findAndEraseUndefined( cv_tools::TaskGraph& _graph );

    /************************************************************************/
    // getLiterals
    //!
    //! \brief search for constant literals and return a reference list
    //!
    //! \details
    //! Numeric literals are interpreted as invariant values stored at memory.
    //! The function returns a map of identification lists (vector).
    //! The key is the invariant value and the vector includes a list of all
    //! nodes that represent that value. The node is indicated via her id.
    //!
    //! \param [in,out] _graph const reference to task graph representation
    //! \return map of value and the node ids that represent that values.
    /************************************************************************/
    invariantMap_t getLiterals( const cv_tools::TaskGraph& _graph );

    /************************************************************************/
    // getLiterals
    //!
    //! \brief search for constant literals and return a reference list
    //!
    //! \details
    //! Numeric literals are interpreted as invariant values stored at memory.
    //! The function returns a map of identification lists (vector).
    //! The key is the invariant value and the vector includes a list of all
    //! nodes that represent that value. The node is indicated via her id.
    //!
    //! \param [in,out] _graph const reference to task graph representation
    //! \return map of value and the node ids that represent that values.
    /************************************************************************/
    inputVarList_t getInputVars( const cv_tools::TaskGraph& _graph );


    /************************************************************************/
    // getOutputVars
    //!
    //! \brief search for constant literals and return a reference list
    //!
    //! \details
    //! Numeric literals are interpreted as invariant values stored at memory.
    //! The function returns a map of identification lists (vector).
    //! The key is the invariant value and the vector includes a list of all
    //! nodes that represent that value. The node is indicated via her id.
    //!
    //! \param [in,out] _graph const reference to task graph representation
    //! \return map of value and the node ids that represent that values.
    /************************************************************************/
    outValueMap_t getOutputVars( const cv_tools::TaskGraph& _graph );


    /************************************************************************/
    // getConnectionInfo
    //!
    //! \brief search for constant literals and return a reference list
    //!
    //! \details
    //! Numeric literals are interpreted as invariant values stored at memory.
    //! The function returns a map of identification lists (vector).
    //! The key is the invariant value and the vector includes a list of all
    //! nodes that represent that value. The node is indicated via her id.
    //!
    //! \param [in,out] _graph const reference to task graph representation
    //! \return map of value and the node ids that represent that values.
    /************************************************************************/
    vertexClassList_t getVertexClasses(const cv_tools::TaskGraph& _graph);

    void writeMemoryFileBuildInfo( const inputVarList_t& _inputs, const invariantMap_t& _invariants,
        const outValueMap_t& _outputs );

    void writeVertexTypeDefinitions(const vertexClassList_t& _vertices);

}

#endif // !TG_VERTEX_BUILDER_H_
